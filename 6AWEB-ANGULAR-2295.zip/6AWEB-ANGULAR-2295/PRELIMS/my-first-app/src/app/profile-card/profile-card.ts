import { Component } from '@angular/core';

@Component({
  selector: 'app-profile-card',
  standalone: true,
  templateUrl: './profile-card.html',
  styleUrl: './profile-card.css'
})
export class ProfileCard {
  cardTitle = 'About Me';
  description = 'I am a student learning to build modern web applications with Angular. I also love to eat, sleep, and repeat.';
}
